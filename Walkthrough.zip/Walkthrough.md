```python
#import pandas, read in .csv file 
import pandas
data = pandas.read_csv('brain_size.csv', sep=';', na_values=".")
data 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Gender</th>
      <th>FSIQ</th>
      <th>VIQ</th>
      <th>PIQ</th>
      <th>Weight</th>
      <th>Height</th>
      <th>MRI_Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Female</td>
      <td>133</td>
      <td>132</td>
      <td>124</td>
      <td>118.0</td>
      <td>64.5</td>
      <td>816932</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Male</td>
      <td>140</td>
      <td>150</td>
      <td>124</td>
      <td>NaN</td>
      <td>72.5</td>
      <td>1001121</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Male</td>
      <td>139</td>
      <td>123</td>
      <td>150</td>
      <td>143.0</td>
      <td>73.3</td>
      <td>1038437</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Male</td>
      <td>133</td>
      <td>129</td>
      <td>128</td>
      <td>172.0</td>
      <td>68.8</td>
      <td>965353</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Female</td>
      <td>137</td>
      <td>132</td>
      <td>134</td>
      <td>147.0</td>
      <td>65.0</td>
      <td>951545</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>Female</td>
      <td>99</td>
      <td>90</td>
      <td>110</td>
      <td>146.0</td>
      <td>69.0</td>
      <td>928799</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>Female</td>
      <td>138</td>
      <td>136</td>
      <td>131</td>
      <td>138.0</td>
      <td>64.5</td>
      <td>991305</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Female</td>
      <td>92</td>
      <td>90</td>
      <td>98</td>
      <td>175.0</td>
      <td>66.0</td>
      <td>854258</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>Male</td>
      <td>89</td>
      <td>93</td>
      <td>84</td>
      <td>134.0</td>
      <td>66.3</td>
      <td>904858</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Male</td>
      <td>133</td>
      <td>114</td>
      <td>147</td>
      <td>172.0</td>
      <td>68.8</td>
      <td>955466</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>Female</td>
      <td>132</td>
      <td>129</td>
      <td>124</td>
      <td>118.0</td>
      <td>64.5</td>
      <td>833868</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>Male</td>
      <td>141</td>
      <td>150</td>
      <td>128</td>
      <td>151.0</td>
      <td>70.0</td>
      <td>1079549</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>Male</td>
      <td>135</td>
      <td>129</td>
      <td>124</td>
      <td>155.0</td>
      <td>69.0</td>
      <td>924059</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>Female</td>
      <td>140</td>
      <td>120</td>
      <td>147</td>
      <td>155.0</td>
      <td>70.5</td>
      <td>856472</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>Female</td>
      <td>96</td>
      <td>100</td>
      <td>90</td>
      <td>146.0</td>
      <td>66.0</td>
      <td>878897</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>Female</td>
      <td>83</td>
      <td>71</td>
      <td>96</td>
      <td>135.0</td>
      <td>68.0</td>
      <td>865363</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>Female</td>
      <td>132</td>
      <td>132</td>
      <td>120</td>
      <td>127.0</td>
      <td>68.5</td>
      <td>852244</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>Male</td>
      <td>100</td>
      <td>96</td>
      <td>102</td>
      <td>178.0</td>
      <td>73.5</td>
      <td>945088</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>Female</td>
      <td>101</td>
      <td>112</td>
      <td>84</td>
      <td>136.0</td>
      <td>66.3</td>
      <td>808020</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>Male</td>
      <td>80</td>
      <td>77</td>
      <td>86</td>
      <td>180.0</td>
      <td>70.0</td>
      <td>889083</td>
    </tr>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>Male</td>
      <td>83</td>
      <td>83</td>
      <td>86</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>892420</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>Male</td>
      <td>97</td>
      <td>107</td>
      <td>84</td>
      <td>186.0</td>
      <td>76.5</td>
      <td>905940</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>Female</td>
      <td>135</td>
      <td>129</td>
      <td>134</td>
      <td>122.0</td>
      <td>62.0</td>
      <td>790619</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>Male</td>
      <td>139</td>
      <td>145</td>
      <td>128</td>
      <td>132.0</td>
      <td>68.0</td>
      <td>955003</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>Female</td>
      <td>91</td>
      <td>86</td>
      <td>102</td>
      <td>114.0</td>
      <td>63.0</td>
      <td>831772</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>Male</td>
      <td>141</td>
      <td>145</td>
      <td>131</td>
      <td>171.0</td>
      <td>72.0</td>
      <td>935494</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>Female</td>
      <td>85</td>
      <td>90</td>
      <td>84</td>
      <td>140.0</td>
      <td>68.0</td>
      <td>798612</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>Male</td>
      <td>103</td>
      <td>96</td>
      <td>110</td>
      <td>187.0</td>
      <td>77.0</td>
      <td>1062462</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>Female</td>
      <td>77</td>
      <td>83</td>
      <td>72</td>
      <td>106.0</td>
      <td>63.0</td>
      <td>793549</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>Female</td>
      <td>130</td>
      <td>126</td>
      <td>124</td>
      <td>159.0</td>
      <td>66.5</td>
      <td>866662</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31</td>
      <td>Female</td>
      <td>133</td>
      <td>126</td>
      <td>132</td>
      <td>127.0</td>
      <td>62.5</td>
      <td>857782</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>Male</td>
      <td>144</td>
      <td>145</td>
      <td>137</td>
      <td>191.0</td>
      <td>67.0</td>
      <td>949589</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>Male</td>
      <td>103</td>
      <td>96</td>
      <td>110</td>
      <td>192.0</td>
      <td>75.5</td>
      <td>997925</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>Male</td>
      <td>90</td>
      <td>96</td>
      <td>86</td>
      <td>181.0</td>
      <td>69.0</td>
      <td>879987</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>Female</td>
      <td>83</td>
      <td>90</td>
      <td>81</td>
      <td>143.0</td>
      <td>66.5</td>
      <td>834344</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>Female</td>
      <td>133</td>
      <td>129</td>
      <td>128</td>
      <td>153.0</td>
      <td>66.5</td>
      <td>948066</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>Male</td>
      <td>140</td>
      <td>150</td>
      <td>124</td>
      <td>144.0</td>
      <td>70.5</td>
      <td>949395</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>Female</td>
      <td>88</td>
      <td>86</td>
      <td>94</td>
      <td>139.0</td>
      <td>64.5</td>
      <td>893983</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>Male</td>
      <td>81</td>
      <td>90</td>
      <td>74</td>
      <td>148.0</td>
      <td>74.0</td>
      <td>930016</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>Male</td>
      <td>89</td>
      <td>91</td>
      <td>89</td>
      <td>179.0</td>
      <td>75.5</td>
      <td>935863</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Import Numpycreate arrays, designate t, sin_t, cos_t
import numpy as np
t = np.linspace(-6, 6, 20)
sin_t = np.sin(t)
cos_t = np.cos(t)
```


```python
#show table with designated t, sin,qnd cos values
pandas.DataFrame({'t': t, 'sin': sin_t, 'cos': cos_t})  
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>t</th>
      <th>sin</th>
      <th>cos</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-6.000000</td>
      <td>0.279415</td>
      <td>0.960170</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-5.368421</td>
      <td>0.792419</td>
      <td>0.609977</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-4.736842</td>
      <td>0.999701</td>
      <td>0.024451</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-4.105263</td>
      <td>0.821291</td>
      <td>-0.570509</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-3.473684</td>
      <td>0.326021</td>
      <td>-0.945363</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-2.842105</td>
      <td>-0.295030</td>
      <td>-0.955488</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-2.210526</td>
      <td>-0.802257</td>
      <td>-0.596979</td>
    </tr>
    <tr>
      <th>7</th>
      <td>-1.578947</td>
      <td>-0.999967</td>
      <td>-0.008151</td>
    </tr>
    <tr>
      <th>8</th>
      <td>-0.947368</td>
      <td>-0.811882</td>
      <td>0.583822</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-0.315789</td>
      <td>-0.310567</td>
      <td>0.950551</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.315789</td>
      <td>0.310567</td>
      <td>0.950551</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.947368</td>
      <td>0.811882</td>
      <td>0.583822</td>
    </tr>
    <tr>
      <th>12</th>
      <td>1.578947</td>
      <td>0.999967</td>
      <td>-0.008151</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2.210526</td>
      <td>0.802257</td>
      <td>-0.596979</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2.842105</td>
      <td>0.295030</td>
      <td>-0.955488</td>
    </tr>
    <tr>
      <th>15</th>
      <td>3.473684</td>
      <td>-0.326021</td>
      <td>-0.945363</td>
    </tr>
    <tr>
      <th>16</th>
      <td>4.105263</td>
      <td>-0.821291</td>
      <td>-0.570509</td>
    </tr>
    <tr>
      <th>17</th>
      <td>4.736842</td>
      <td>-0.999701</td>
      <td>0.024451</td>
    </tr>
    <tr>
      <th>18</th>
      <td>5.368421</td>
      <td>-0.792419</td>
      <td>0.609977</td>
    </tr>
    <tr>
      <th>19</th>
      <td>6.000000</td>
      <td>-0.279415</td>
      <td>0.960170</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 40 rows and 8 columns
data.shape 
```




    (40, 8)




```python
 # It has columns , show them
data.columns 
```




    Index(['Unnamed: 0', 'Gender', 'FSIQ', 'VIQ', 'PIQ', 'Weight', 'Height',
           'MRI_Count'],
          dtype='object')




```python
# Columns can be addressed by name (gender)
print(data['Gender'])
```

    0     Female
    1       Male
    2       Male
    3       Male
    4     Female
    5     Female
    6     Female
    7     Female
    8       Male
    9       Male
    10    Female
    11      Male
    12      Male
    13    Female
    14    Female
    15    Female
    16    Female
    17      Male
    18    Female
    19      Male
    20      Male
    21      Male
    22    Female
    23      Male
    24    Female
    25      Male
    26    Female
    27      Male
    28    Female
    29    Female
    30    Female
    31      Male
    32      Male
    33      Male
    34    Female
    35    Female
    36      Male
    37    Female
    38      Male
    39      Male
    Name: Gender, dtype: object



```python
# Simpler selector
data[data['Gender'] == 'Female']['VIQ'].mean()
```




    np.float64(109.45)




```python
# group by gender and print mean values
groupby_gender = data.groupby('Gender')
for gender, value in groupby_gender['VIQ']:
    print((gender, value.mean()))
```

    ('Female', np.float64(109.45))
    ('Male', np.float64(115.25))



```python
#group by gender, and createcolumns with previous designations (FSIQ, VIQ, PIQ, Weight, Height
groupby_gender.mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>FSIQ</th>
      <th>VIQ</th>
      <th>PIQ</th>
      <th>Weight</th>
      <th>Height</th>
      <th>MRI_Count</th>
    </tr>
    <tr>
      <th>Gender</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Female</th>
      <td>19.65</td>
      <td>111.9</td>
      <td>109.45</td>
      <td>110.45</td>
      <td>137.200000</td>
      <td>65.765000</td>
      <td>862654.6</td>
    </tr>
    <tr>
      <th>Male</th>
      <td>21.35</td>
      <td>115.0</td>
      <td>115.25</td>
      <td>111.60</td>
      <td>166.444444</td>
      <td>71.431579</td>
      <td>954855.4</td>
    </tr>
  </tbody>
</table>
</div>




```python
# the code from the website would not run.
##from pandas.tools import plotting

# scatter matrix will not run. It comes up with same error about module not found. Google suggests pandas is out of date
## plotting.scatter_matrix(data[['Weight', 'Height', 'MRI_Count']])   
```


```python
#tried a new import according to Google
from pandas.plotting import scatter_matrix

# new scatter matrix that
scatter_matrix(data[['Weight', 'Height', 'MRI_Count']])

```




    array([[<Axes: xlabel='Weight', ylabel='Weight'>,
            <Axes: xlabel='Height', ylabel='Weight'>,
            <Axes: xlabel='MRI_Count', ylabel='Weight'>],
           [<Axes: xlabel='Weight', ylabel='Height'>,
            <Axes: xlabel='Height', ylabel='Height'>,
            <Axes: xlabel='MRI_Count', ylabel='Height'>],
           [<Axes: xlabel='Weight', ylabel='MRI_Count'>,
            <Axes: xlabel='Height', ylabel='MRI_Count'>,
            <Axes: xlabel='MRI_Count', ylabel='MRI_Count'>]], dtype=object)




    
![png](output_10_1.png)
    



```python
#similar errors as above, 
##plotting.scatter_matrix(data[['PIQ', 'VIQ', 'FSIQ']])   
```


```python
# new scatter matrix that runs the same way as previous code
# scatter matrix with PIQ, VIQ, FSIQ
scatter_matrix(data[['PIQ', 'VIQ', 'FSIQ']])
```




    array([[<Axes: xlabel='PIQ', ylabel='PIQ'>,
            <Axes: xlabel='VIQ', ylabel='PIQ'>,
            <Axes: xlabel='FSIQ', ylabel='PIQ'>],
           [<Axes: xlabel='PIQ', ylabel='VIQ'>,
            <Axes: xlabel='VIQ', ylabel='VIQ'>,
            <Axes: xlabel='FSIQ', ylabel='VIQ'>],
           [<Axes: xlabel='PIQ', ylabel='FSIQ'>,
            <Axes: xlabel='VIQ', ylabel='FSIQ'>,
            <Axes: xlabel='FSIQ', ylabel='FSIQ'>]], dtype=object)




    
![png](output_12_1.png)
    



```python
#import stats
from scipy import stats
```


```python
#### Problems with this code below
```


```python
#runs a 1 sample t-test from scipy.stats module testing previously imported data in the VIQ data frame
stats.ttest_1samp(data['VIQ'], 0)   
```




    TtestResult(statistic=np.float64(30.08809997084933), pvalue=np.float64(1.3289196468727879e-28), df=np.int64(39))




```python
# 2-sample t-test looking at males and females
female_viq = data[data['Gender'] == 'Female']['VIQ']
male_viq = data[data['Gender'] == 'Male']['VIQ']
stats.ttest_ind(female_viq, male_viq)   
```




    TtestResult(statistic=np.float64(-0.7726161723275012), pvalue=np.float64(0.44452876778583217), df=np.float64(38.0))




```python
#testing for significant difference
stats.ttest_ind(data['FSIQ'], data['PIQ']) 
```




    TtestResult(statistic=np.float64(0.465637596380964), pvalue=np.float64(0.6427725009414841), df=np.float64(78.0))




```python
# paired samples t-test
stats.ttest_rel(data['FSIQ'], data['PIQ'])   
```




    TtestResult(statistic=np.float64(1.7842019405859857), pvalue=np.float64(0.08217263818364236), df=np.int64(39))




```python
#one sample t-test
stats.ttest_1samp(data['FSIQ'] - data['PIQ'], 0)   
```




    TtestResult(statistic=np.float64(1.7842019405859857), pvalue=np.float64(0.08217263818364236), df=np.int64(39))




```python
#relax assumptions of Gaussian errors
stats.wilcoxon(data['FSIQ'], data['PIQ'])   
```




    WilcoxonResult(statistic=np.float64(274.5), pvalue=np.float64(0.10659492713506856))




```python
### until here
```


```python
# create a dataframe with a linear relationship between x and y 
import numpy as np
x = np.linspace(-5, 5, 20)
np.random.seed(1)
# normal distributed noise using random seed
y = -5 + 3*x + 4 * np.random.normal(size=x.shape)
# Create a data frame containing all the relevant variables
data = pandas.DataFrame({'x': x, 'y': y})
```


```python
#ordinary least squares (OLS) model and fit it
#install statsmodels
!pip install statsmodels
from statsmodels.formula.api import ols
model = ols("y ~ x", data).fit()
```

    Requirement already satisfied: statsmodels in /srv/conda/envs/notebook/lib/python3.9/site-packages (0.14.2)
    Requirement already satisfied: numpy>=1.22.3 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from statsmodels) (2.0.0)
    Requirement already satisfied: scipy!=1.9.2,>=1.8 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from statsmodels) (1.13.1)
    Requirement already satisfied: pandas!=2.1.0,>=1.4 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from statsmodels) (2.2.2)
    Requirement already satisfied: patsy>=0.5.6 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from statsmodels) (0.5.6)
    Requirement already satisfied: packaging>=21.3 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from statsmodels) (24.0)
    Requirement already satisfied: python-dateutil>=2.8.2 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from pandas!=2.1.0,>=1.4->statsmodels) (2.9.0)
    Requirement already satisfied: pytz>=2020.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from pandas!=2.1.0,>=1.4->statsmodels) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from pandas!=2.1.0,>=1.4->statsmodels) (2024.1)
    Requirement already satisfied: six in /srv/conda/envs/notebook/lib/python3.9/site-packages (from patsy>=0.5.6->statsmodels) (1.16.0)



```python
#inspect statistics
print(model.summary())  
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                      y   R-squared:                       0.804
    Model:                            OLS   Adj. R-squared:                  0.794
    Method:                 Least Squares   F-statistic:                     74.03
    Date:                Thu, 11 Jul 2024   Prob (F-statistic):           8.56e-08
    Time:                        00:09:07   Log-Likelihood:                -57.988
    No. Observations:                  20   AIC:                             120.0
    Df Residuals:                      18   BIC:                             122.0
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================
                     coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------
    Intercept     -5.5335      1.036     -5.342      0.000      -7.710      -3.357
    x              2.9369      0.341      8.604      0.000       2.220       3.654
    ==============================================================================
    Omnibus:                        0.100   Durbin-Watson:                   2.956
    Prob(Omnibus):                  0.951   Jarque-Bera (JB):                0.322
    Skew:                          -0.058   Prob(JB):                        0.851
    Kurtosis:                       2.390   Cond. No.                         3.03
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



```python
#redesignate .csv to data
data = pandas.read_csv('brain_size.csv', sep=';', na_values=".")
```


```python
# force categorical
model = ols('VIQ ~ C(Gender)', data).fit()
```


```python
#log form table.indicate IQ as categorical value
data_fisq = pandas.DataFrame({'iq': data['FSIQ'], 'type': 'fsiq'})
data_piq = pandas.DataFrame({'iq': data['PIQ'], 'type': 'piq'})
data_long = pandas.concat((data_fisq, data_piq))
print(data_long)  
model = ols("iq ~ type", data_long).fit()
print(model.summary())  
```

         iq  type
    0   133  fsiq
    1   140  fsiq
    2   139  fsiq
    3   133  fsiq
    4   137  fsiq
    ..  ...   ...
    35  128   piq
    36  124   piq
    37   94   piq
    38   74   piq
    39   89   piq
    
    [80 rows x 2 columns]
                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                     iq   R-squared:                       0.003
    Model:                            OLS   Adj. R-squared:                 -0.010
    Method:                 Least Squares   F-statistic:                    0.2168
    Date:                Thu, 11 Jul 2024   Prob (F-statistic):              0.643
    Time:                        00:13:20   Log-Likelihood:                -364.35
    No. Observations:                  80   AIC:                             732.7
    Df Residuals:                      78   BIC:                             737.5
    Df Model:                           1                                         
    Covariance Type:            nonrobust                                         
    ===============================================================================
                      coef    std err          t      P>|t|      [0.025      0.975]
    -------------------------------------------------------------------------------
    Intercept     113.4500      3.683     30.807      0.000     106.119     120.781
    type[T.piq]    -2.4250      5.208     -0.466      0.643     -12.793       7.943
    ==============================================================================
    Omnibus:                      164.598   Durbin-Watson:                   1.531
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):                8.062
    Skew:                          -0.110   Prob(JB):                       0.0178
    Kurtosis:                       1.461   Cond. No.                         2.62
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



```python
#ttest and statistical test
stats.ttest_ind(data['FSIQ'], data['PIQ'])   
```




    TtestResult(statistic=np.float64(0.465637596380964), pvalue=np.float64(0.6427725009414841), df=np.float64(78.0))




```python
#read CSV file, Fits OLS regression model, prints summary 
data = pandas.read_csv('iris.csv')
model = ols('sepal_width ~ name + petal_length', data).fit()
print(model.summary()) 
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:            sepal_width   R-squared:                       0.478
    Model:                            OLS   Adj. R-squared:                  0.468
    Method:                 Least Squares   F-statistic:                     44.63
    Date:                Thu, 11 Jul 2024   Prob (F-statistic):           1.58e-20
    Time:                        00:43:11   Log-Likelihood:                -38.185
    No. Observations:                 150   AIC:                             84.37
    Df Residuals:                     146   BIC:                             96.41
    Df Model:                           3                                         
    Covariance Type:            nonrobust                                         
    ======================================================================================
                             coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------------
    Intercept              2.9813      0.099     29.989      0.000       2.785       3.178
    name[T.versicolor]    -1.4821      0.181     -8.190      0.000      -1.840      -1.124
    name[T.virginica]     -1.6635      0.256     -6.502      0.000      -2.169      -1.158
    petal_length           0.2983      0.061      4.920      0.000       0.178       0.418
    ==============================================================================
    Omnibus:                        2.868   Durbin-Watson:                   1.753
    Prob(Omnibus):                  0.238   Jarque-Bera (JB):                2.885
    Skew:                          -0.082   Prob(JB):                        0.236
    Kurtosis:                       3.659   Cond. No.                         54.0
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



```python
#print model, no signiicant difference (greater than 0.05)
print(model.f_test([0, 1, -1, 0]))  
```

    <F test: F=3.245335346574177, p=0.07369058781701142, df_denom=146, df_num=1>



```python
#show data
print(data)  
```

         sepal_length  sepal_width  petal_length  petal_width       name
    0             5.1          3.5           1.4          0.2     setosa
    1             4.9          3.0           1.4          0.2     setosa
    2             4.7          3.2           1.3          0.2     setosa
    3             4.6          3.1           1.5          0.2     setosa
    4             5.0          3.6           1.4          0.2     setosa
    ..            ...          ...           ...          ...        ...
    145           6.7          3.0           5.2          2.3  virginica
    146           6.3          2.5           5.0          1.9  virginica
    147           6.5          3.0           5.2          2.0  virginica
    148           6.2          3.4           5.4          2.3  virginica
    149           5.9          3.0           5.1          1.8  virginica
    
    [150 rows x 5 columns]



```python

```

    Collecting seaborn
      Downloading seaborn-0.13.2-py3-none-any.whl.metadata (5.4 kB)
    Requirement already satisfied: numpy!=1.24.0,>=1.20 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from seaborn) (2.0.0)
    Requirement already satisfied: pandas>=1.2 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from seaborn) (2.2.2)
    Requirement already satisfied: matplotlib!=3.6.1,>=3.4 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from seaborn) (3.8.4)
    Requirement already satisfied: contourpy>=1.0.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.2.1)
    Requirement already satisfied: cycler>=0.10 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (4.53.1)
    Requirement already satisfied: kiwisolver>=1.3.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (1.4.5)
    Requirement already satisfied: packaging>=20.0 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (24.0)
    Requirement already satisfied: pillow>=8 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (9.2.0)
    Requirement already satisfied: pyparsing>=2.3.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (2.9.0)
    Requirement already satisfied: importlib-resources>=3.2.0 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn) (6.4.0)
    Requirement already satisfied: pytz>=2020.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from pandas>=1.2->seaborn) (2024.1)
    Requirement already satisfied: zipp>=3.1.0 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from importlib-resources>=3.2.0->matplotlib!=3.6.1,>=3.4->seaborn) (3.17.0)
    Requirement already satisfied: six>=1.5 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from python-dateutil>=2.7->matplotlib!=3.6.1,>=3.4->seaborn) (1.16.0)
    Downloading seaborn-0.13.2-py3-none-any.whl (294 kB)
    [2K   [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m294.9/294.9 kB[0m [31m4.9 MB/s[0m eta [36m0:00:00[0mta [36m0:00:01[0m
    [?25hInstalling collected packages: seaborn
    Successfully installed seaborn-0.13.2



```python
#install seaborn 
!pip install seaborn[stats]
```

    Requirement already satisfied: seaborn[stats] in /srv/conda/envs/notebook/lib/python3.9/site-packages (0.13.2)
    Requirement already satisfied: numpy!=1.24.0,>=1.20 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from seaborn[stats]) (2.0.0)
    Requirement already satisfied: pandas>=1.2 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from seaborn[stats]) (2.2.2)
    Requirement already satisfied: matplotlib!=3.6.1,>=3.4 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from seaborn[stats]) (3.8.4)
    Requirement already satisfied: scipy>=1.7 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from seaborn[stats]) (1.13.1)
    Requirement already satisfied: statsmodels>=0.12 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from seaborn[stats]) (0.14.2)
    Requirement already satisfied: contourpy>=1.0.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (1.2.1)
    Requirement already satisfied: cycler>=0.10 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (4.53.1)
    Requirement already satisfied: kiwisolver>=1.3.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (1.4.5)
    Requirement already satisfied: packaging>=20.0 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (24.0)
    Requirement already satisfied: pillow>=8 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (9.2.0)
    Requirement already satisfied: pyparsing>=2.3.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (3.1.2)
    Requirement already satisfied: python-dateutil>=2.7 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (2.9.0)
    Requirement already satisfied: importlib-resources>=3.2.0 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from matplotlib!=3.6.1,>=3.4->seaborn[stats]) (6.4.0)
    Requirement already satisfied: pytz>=2020.1 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from pandas>=1.2->seaborn[stats]) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from pandas>=1.2->seaborn[stats]) (2024.1)
    Requirement already satisfied: patsy>=0.5.6 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from statsmodels>=0.12->seaborn[stats]) (0.5.6)
    Requirement already satisfied: zipp>=3.1.0 in /srv/conda/envs/notebook/lib/python3.9/site-packages (from importlib-resources>=3.2.0->matplotlib!=3.6.1,>=3.4->seaborn[stats]) (3.17.0)
    Requirement already satisfied: six in /srv/conda/envs/notebook/lib/python3.9/site-packages (from patsy>=0.5.6->statsmodels>=0.12->seaborn[stats]) (1.16.0)



```python
#new import, regression lines for variables (from3.1.4 problem with seaborn) data is still "iris.csv data but im not sure how to get seaborn data in instead... there is no .csv to downl;oad/

import seaborn as sns
data = sns.load_dataset
seaborn.pairplot(data, vars=['WAGE', 'AGE', 'EDUCATION'],
                 kind='reg')  
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[4], line 5
          3 import seaborn as sns
          4 data = sns.load_dataset
    ----> 5 seaborn.pairplot(data, vars=['WAGE', 'AGE', 'EDUCATION'],
          6                  kind='reg')  


    NameError: name 'seaborn' is not defined



```python
#plot categorical variables as the hue
seaborn.pairplot(data, vars=['WAGE', 'AGE', 'EDUCATION'],
                 kind='reg', hue='SEX')  
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[1], line 1
    ----> 1 seaborn.pairplot(data, vars=['WAGE', 'AGE', 'EDUCATION'],
          2                  kind='reg', hue='SEX')  


    NameError: name 'seaborn' is not defined



```python
from matplotlib import pyplot as plt
plt.rcdefaults()
```


```python
seaborn.lmplot(y='WAGE', x='EDUCATION', data=data) 
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[1], line 1
    ----> 1 seaborn.lmplot(y='WAGE', x='EDUCATION', data=data) 


    NameError: name 'seaborn' is not defined



```python
result = sm.ols(formula='wage ~ education + gender + education * gender',
                data=data).fit()    
print(result.summary()) 
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[2], line 1
    ----> 1 result = sm.ols(formula='wage ~ education + gender + education * gender',
          2                 data=data).fit()    
          3 print(result.summary()) 


    NameError: name 'sm' is not defined



```python

```
